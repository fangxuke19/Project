#ifndef __SNIFFER_IOCTL_
#define __SNIFFER_IOCTL__

struct sniffer_flow_entry {
    uint32_t src_ip;
  	uint32_t dst_ip;
  	uint16_t src_port;
  	uint16_t dst_port;
  	int action;
  	char* dev_file;	
};


#define SNIFFER_IOC_MAGIC       'p'

#define SNIFFER_FLOW_ENABLE     _IOW(SNIFFER_IOC_MAGIC, 0x1, struct sniffer_flow_entry)
#define SNIFFER_FLOW_DISABLE    _IOW(SNIFFER_IOC_MAGIC, 0x2, struct sniffer_flow_entry)

#define SNIFFER_IOC_MAXNR   0x3


#define SNIFFER_ACTION_NULL     0x0
#define SNIFFER_ACTION_CAPTURE  0x1
#define SNIFFER_ACTION_DPI      0x2
//ACTIONS
#define NONE 0
#define CAPTURING 1
#define DPI 2
//DPI Pattern 
#define PATTERN "You got it!"

#endif /* __SNIFFER_IOCTL__ */
/*
  *struct for ip header
  */
 typedef struct {
  uint8_t version_ihl;
  uint8_t dscp_ecn;  
  uint8_t total_len[2];
  uint8_t identification[2];
  uint8_t flags_frag[2];
  uint8_t time_to_live;
  uint8_t protocol;
  uint8_t checksum[2];
  // uint8_t src_ip[4];
  // uint8_t dst_ip[4];
  uint32_t src_ip;
  uint32_t dst_ip;
  uint8_t options_and_data[0];
} ip_hdr_t;
/*
 *struct for the tcp header
 */
typedef struct    
{
  uint8_t src_port[2];
  uint8_t dst_port[2];
  uint8_t seq_num[4];
  uint8_t ack_num[4];
  uint8_t data_res_ns;
  uint8_t flags;
  #define FIN  0x01
  #define SYN  0x02
  #define RST  0x04
  #define PUSH 0x08
  #define ACK  0x10   
  #define URG  0x20
  #define ECE  0x40
  #define CWR  0x80
  uint8_t window[2];
  uint8_t checksum[2];
  uint8_t urgent_p[2];
  uint8_t options_and_data[0];
}tcp_hdr_t;
